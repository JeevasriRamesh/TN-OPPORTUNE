/**
 * schemeRoutes.js
 * Defines read-only routes for schemes.
 */

const express = require("express");
const { getSchemes } = require("../controllers/schemeController");

const router = express.Router();

// GET /api/schemes - returns all schemes, with optional filters via query params
router.get("/", getSchemes);

module.exports = router;

