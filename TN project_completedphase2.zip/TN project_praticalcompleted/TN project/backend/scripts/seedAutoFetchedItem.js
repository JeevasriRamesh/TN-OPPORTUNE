/**
 * seedAutoFetchedItem.js
 * Inserts ONE test auto-fetched item for admin dashboard testing.
 * Run from backend: node scripts/seedAutoFetchedItem.js
 *
 * Job auto-fetch disabled until official sources are finalized
 */

require("dotenv").config();

// Job auto-fetch disabled until official sources are finalized
// No test job insertion - exit without modifying database
console.log("Job auto-fetch disabled. Exiting.");
process.exit(0);
