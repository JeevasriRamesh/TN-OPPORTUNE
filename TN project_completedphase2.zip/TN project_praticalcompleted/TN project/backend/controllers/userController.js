/**
 * userController.js
 * Controller functions related to user-specific operations.
 * Here we handle storing and fetching applied schemes for a user.
 */

const User = require("../models/User");
const Scheme = require("../models/Scheme");

/**
 * POST /api/users/apply/:schemeId
 * Adds a scheme to the user's appliedSchemes list.
 * - Expects userId in the request body
 * - Expects schemeId as a URL parameter
 * - Checks that both user and scheme exist
 * - Prevents duplicate entries
 */
const applyForScheme = async (req, res) => {
  try {
    const { userId } = req.body;
    const { schemeId } = req.params;

    // Basic validation: both IDs must be present
    if (!userId || !schemeId) {
      return res.status(400).json({ message: "userId in body and schemeId in URL are required" });
    }

    // Make sure the user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Make sure the scheme exists
    const scheme = await Scheme.findById(schemeId);
    if (!scheme) {
      return res.status(404).json({ message: "Scheme not found" });
    }

    // Check if this scheme is already in the user's appliedSchemes array
    const alreadyApplied = user.appliedSchemes.some(
      (id) => id.toString() === schemeId
    );

    if (alreadyApplied) {
      return res.status(200).json({
        message: "Scheme already marked as applied for this user",
        userId: user._id,
        schemeId,
      });
    }

    // Add scheme to appliedSchemes and save
    user.appliedSchemes.push(schemeId);
    await user.save();

    return res.status(200).json({
      message: "Scheme marked as applied for user",
      userId: user._id,
      schemeId,
    });
  } catch (error) {
    console.error("Error marking scheme as applied:", error.message);
    return res.status(500).json({ message: "Failed to mark scheme as applied" });
  }
};

/**
 * GET /api/users/:userId/applied
 * Returns all schemes that the user has applied for.
 * - Validates that the user exists
 * - Populates the appliedSchemes field with full scheme documents
 */
const getAppliedSchemes = async (req, res) => {
  try {
    const { userId } = req.params;

    // Validate that a userId was provided
    if (!userId) {
      return res.status(400).json({ message: "userId is required in the URL" });
    }

    // Find the user and populate appliedSchemes with full Scheme details
    const user = await User.findById(userId).populate("appliedSchemes");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Return just the array of populated schemes
    return res.json(user.appliedSchemes || []);
  } catch (error) {
    console.error("Error fetching applied schemes:", error.message);
    return res.status(500).json({ message: "Failed to fetch applied schemes" });
  }
};

module.exports = {
  applyForScheme,
  getAppliedSchemes,
};

